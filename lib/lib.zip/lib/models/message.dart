class Message{
  String message;
  String user;
  String name;
  Message({this.message,this.user,this.name});
}