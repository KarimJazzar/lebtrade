class Item{
  String name;
  String userid;
  int condition;
  String cat1;
  String cat2;
  String cat3;
  String brand;
  String tradefor;
  String description;
  String imageUrl;
  Item({this.name,this.userid, this.condition,this.cat1, this.cat2, this.cat3, this.brand, this.tradefor, this.description, this.imageUrl});
}