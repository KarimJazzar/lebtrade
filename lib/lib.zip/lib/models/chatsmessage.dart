class ChatsMessage{
  String contacts;
  String message1;
  String message2;

  ChatsMessage({this.contacts,this.message1,this.message2});
}